# PDF Voice Reader — Tablet Cloud Build

This project is intended to be built by GitHub Actions from an Android tablet.

Features:
- Open PDF
- Read current page aloud
- Read all pages aloud
- OCR rendered PDF pages, so no copy/highlight is required
- English/Arabic/Auto language modes
- Android Text-to-Speech

Arabic OCR model is downloaded automatically by the GitHub Actions build from the official Tesseract tessdata_fast repository.
