package com.ammar.pdfvoicereader;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.speech.tts.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.googlecode.tesseract.android.TessBaseAPI;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    private static final int PICK_PDF = 1001;
    private PdfRenderer renderer;
    private ParcelFileDescriptor pfd;
    private int pageIndex = 0;
    private ImageView pageView;
    private TextView status, pageLabel;
    private Spinner language;
    private SeekBar speed;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private TessBaseAPI tess;
    private final AtomicBoolean readingAll = new AtomicBoolean(false);
    private Uri pdfUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        tts = new TextToSpeech(this, this);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,12);

        TextView title = new TextView(this);
        title.setText("PDF Voice Reader"); title.setTextSize(26); title.setPadding(0,0,0,10);
        root.addView(title);

        MaterialButton open = new MaterialButton(this); open.setText("OPEN PDF");
        root.addView(open, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this); status.setText("Choose a PDF. The app reads the page itself — no copy or highlight needed.");
        status.setPadding(0,10,0,8); root.addView(status);

        pageView = new ImageView(this); pageView.setBackgroundColor(Color.rgb(235,235,235)); pageView.setAdjustViewBounds(true); pageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(pageView, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        MaterialButton prev = new MaterialButton(this); prev.setText("◀");
        MaterialButton next = new MaterialButton(this); next.setText("▶");
        pageLabel = new TextView(this); pageLabel.setGravity(Gravity.CENTER); pageLabel.setText("Page 0 / 0");
        nav.addView(prev,new LinearLayout.LayoutParams(0,52,1)); nav.addView(pageLabel,new LinearLayout.LayoutParams(0,52,2)); nav.addView(next,new LinearLayout.LayoutParams(0,52,1));
        root.addView(nav);

        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL);
        MaterialButton readPage = new MaterialButton(this); readPage.setText("🔊 READ PAGE");
        MaterialButton readAll = new MaterialButton(this); readAll.setText("▶ READ ALL");
        MaterialButton stop = new MaterialButton(this); stop.setText("■ STOP");
        controls.addView(readPage,new LinearLayout.LayoutParams(0,58,1)); controls.addView(readAll,new LinearLayout.LayoutParams(0,58,1)); controls.addView(stop,new LinearLayout.LayoutParams(0,58,1));
        root.addView(controls);

        LinearLayout settings = new LinearLayout(this); settings.setOrientation(LinearLayout.HORIZONTAL);
        language = new Spinner(this); String[] langs={"Auto (English + Arabic)","English","العربية"}; language.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,langs));
        settings.addView(language,new LinearLayout.LayoutParams(0,58,1));
        speed = new SeekBar(this); speed.setMax(150); speed.setProgress(50); settings.addView(speed,new LinearLayout.LayoutParams(0,58,1));
        root.addView(settings);

        open.setOnClickListener(v -> pickPdf());
        prev.setOnClickListener(v -> changePage(-1)); next.setOnClickListener(v -> changePage(1));
        readPage.setOnClickListener(v -> readCurrentPage()); readAll.setOnClickListener(v -> readAllPages()); stop.setOnClickListener(v -> stopReading());
        setContentView(root);
    }

    private void pickPdf() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/pdf"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_PDF);
    }

    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(r==PICK_PDF && c==RESULT_OK && d!=null){ openPdf(d.getData()); } }

    private void openPdf(Uri uri){
        try {
            stopReading(); closePdf();
            pfd=getContentResolver().openFileDescriptor(uri,"r");
            if(pfd==null) throw new IOException("Cannot open file");
            renderer=new PdfRenderer(pfd); pdfUri=uri; pageIndex=0; renderPage();
            status.setText("PDF opened • " + renderer.getPageCount() + " pages • Tap READ PAGE or READ ALL");
        } catch(Exception e){ status.setText("Could not open PDF: "+e.getMessage()); }
    }

    private void renderPage(){
        if(renderer==null)return;
        PdfRenderer.Page page=null; Bitmap bitmap=null;
        try{
            page=renderer.openPage(pageIndex);
            int w=Math.min(page.getWidth()*2,2200); int h=Math.round(w*(page.getHeight()/(float)page.getWidth()));
            bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE);
            page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            pageView.setImageBitmap(bitmap); pageLabel.setText("Page "+(pageIndex+1)+" / "+renderer.getPageCount());
        }catch(Exception e){status.setText("Render error: "+e.getMessage());} finally {if(page!=null)page.close();}
    }

    private void changePage(int delta){ if(renderer==null)return; int n=pageIndex+delta; if(n<0||n>=renderer.getPageCount())return; pageIndex=n; renderPage(); }

    private Bitmap renderForOcr(int index) throws Exception {
        PdfRenderer.Page page=renderer.openPage(index);
        int w=Math.min(page.getWidth()*2,2200); int h=Math.round(w*(page.getHeight()/(float)page.getWidth()));
        Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); b.eraseColor(Color.WHITE);
        page.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_PRINT); page.close(); return b;
    }

    private void readCurrentPage(){
        if(renderer==null){toast("Open a PDF first");return;}
        final int idx=pageIndex; status.setText("OCR: page "+(idx+1)+"…");
        new Thread(() -> {
            try { String text=ocr(renderForOcr(idx)); runOnUiThread(() -> {status.setText("Page "+(idx+1)+" ready"); speakText(text,true);}); }
            catch(Exception e){runOnUiThread(()->status.setText("OCR error: "+e.getMessage()));}
        }).start();
    }

    private void readAllPages(){
        if(renderer==null){toast("Open a PDF first");return;} if(readingAll.getAndSet(true))return;
        new Thread(() -> {
            try{
                for(int i=pageIndex;i<renderer.getPageCount() && readingAll.get();i++){
                    final int p=i; runOnUiThread(()->{pageIndex=p;renderPage();status.setText("OCR: page "+(p+1)+" / "+renderer.getPageCount());});
                    String text=ocr(renderForOcr(i));
                    if(!text.trim().isEmpty()) waitForSpeech(text);
                }
            }catch(Exception e){runOnUiThread(()->status.setText("Read All error: "+e.getMessage()));}
            finally{readingAll.set(false);runOnUiThread(()->status.setText("Finished / stopped"));}
        }).start();
    }

    private void waitForSpeech(String text) throws InterruptedException {
        if(!ttsReady)return;
        speakWithLanguage(text, true);
        while(readingAll.get() && tts.isSpeaking()) Thread.sleep(250);
    }

    private void speakText(String text, boolean flush){
        if(!ttsReady){toast("Voice engine is still loading");return;}
        if(text==null||text.trim().isEmpty()){toast("No readable text found on this page");return;}
        speakWithLanguage(text, flush);
    }

    private void speakWithLanguage(String text, boolean flush){
        float rate=.75f+(speed.getProgress()/100f);
        tts.setSpeechRate(rate);
        int pos=language.getSelectedItemPosition();
        if(pos==2){
            tts.setLanguage(new Locale("ar"));
            tts.speak(text,flush?TextToSpeech.QUEUE_FLUSH:TextToSpeech.QUEUE_ADD,null,"pdf-ar");
        } else if(pos==1){
            tts.setLanguage(Locale.ENGLISH);
            tts.speak(text,flush?TextToSpeech.QUEUE_FLUSH:TextToSpeech.QUEUE_ADD,null,"pdf-en");
        } else {
            // Auto: use Arabic voice for Arabic-heavy pages, English otherwise.
            int arabic=0, latin=0;
            for(int i=0;i<text.length();i++){ char c=text.charAt(i);
                if((c>='\u0600'&&c<='\u06FF')||(c>='\u0750'&&c<='\u077F')) arabic++;
                else if((c>='A'&&c<='Z')||(c>='a'&&c<='z')) latin++;
            }
            Locale loc=(arabic>latin)?new Locale("ar"):Locale.ENGLISH;
            tts.setLanguage(loc);
            tts.speak(text,flush?TextToSpeech.QUEUE_FLUSH:TextToSpeech.QUEUE_ADD,null,"pdf-auto");
        }
    }

    private String ocr(Bitmap bitmap) throws Exception {
        prepareTess(); String lang;
        int pos=language.getSelectedItemPosition(); lang=(pos==1)?"eng":(pos==2)?"ara":"eng+ara";
        if(!tess.init(getFilesDir().getAbsolutePath(),lang)) throw new Exception("OCR language data unavailable");
        tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO); tess.setImage(bitmap); String out=tess.getUTF8Text(); tess.clear(); return out==null?"":out;
    }

    private void prepareTess() throws Exception {
        File dir=new File(getFilesDir(),"tessdata");
        if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Cannot create OCR folder");
        // Models are downloaded on first OCR use, so the APK stays small and the
        // app does not require users to copy or install OCR files manually.
        ensureModel("eng", new File(dir,"eng.traineddata"));
        ensureModel("ara", new File(dir,"ara.traineddata"));
        if(tess==null)tess=new TessBaseAPI();
    }

    private void ensureModel(String lang, File dest) throws Exception {
        if(dest.exists() && dest.length()>100000) return;
        File tmp=new File(dest.getParentFile(), dest.getName()+".download");
        String url="https://cdn.jsdelivr.net/gh/tesseract-ocr/tessdata_fast@main/"+lang+".traineddata";
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setRequestMethod("GET"); c.connect();
        if(c.getResponseCode()!=200) throw new IOException("Could not download "+lang+" OCR model (HTTP "+c.getResponseCode()+")");
        try(InputStream in=new BufferedInputStream(c.getInputStream()); OutputStream out=new BufferedOutputStream(new FileOutputStream(tmp))){
            byte[] buf=new byte[16384]; int n; while((n=in.read(buf))!=-1) out.write(buf,0,n);
        } finally { c.disconnect(); }
        if(tmp.length()<100000){ tmp.delete(); throw new IOException("Downloaded "+lang+" OCR model is incomplete"); }
        if(dest.exists()) dest.delete();
        if(!tmp.renameTo(dest)) throw new IOException("Cannot save "+lang+" OCR model");
    }

    private void stopReading(){ readingAll.set(false); if(tts!=null)tts.stop(); }
    private void closePdf(){if(renderer!=null){try{renderer.close();}catch(Exception ignored){}renderer=null;}if(pfd!=null){try{pfd.close();}catch(Exception ignored){}pfd=null;}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override public void onInit(int status){ttsReady=status==TextToSpeech.SUCCESS;if(ttsReady){tts.setLanguage(Locale.ENGLISH);}}
    @Override protected void onDestroy(){stopReading();if(tess!=null){tess.recycle();tess=null;}if(tts!=null){tts.shutdown();tts=null;}closePdf();super.onDestroy();}
}
