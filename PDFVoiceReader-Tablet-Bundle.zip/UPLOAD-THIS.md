# TABLET UPLOAD — DO NOT UNZIP THE SOURCE ZIP

On GitHub, create a repository, then upload:
1. PDFVoiceReader-source.zip (keep it as ONE ZIP file)
2. .github/workflows/build.yml (this file must be in the .github/workflows folder)

Then open Actions -> Build PDF Voice Reader APK -> Run workflow if it does not start automatically.
Download the artifact PDFVoiceReader-debug-APK and install app-debug.apk.
